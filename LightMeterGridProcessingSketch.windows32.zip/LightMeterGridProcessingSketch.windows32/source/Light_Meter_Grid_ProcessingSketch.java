import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.serial.*; 
import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Light_Meter_Grid_ProcessingSketch extends PApplet {

// This is a light map meter helper tool, designed for the LCD resin printer Anycubic Photon, but can be used with any other LCD printer
// It uses a simples serial read from any capable device configured to send a serial print trough it's com. 

// TODO:
// Add on the fly node nr configuration(preset as photon grid)
// Add Photonsters logo and branding
// Add import CSV capability (Not important)


String serialRead = "No Data";
int baudRate = 57600;
int marginx = 100;
int marginy = 150;
int gxpos = 75;
int gypos = 125;
int xnodesnr = 11;
int ynodesnr = 6;
int xynodespacing = 5;

gridBlock gb1;
gridNode btnrst;
gridNode btnsave;

public void setup(){
  
  clear();
  
  frameRate(30);
  textSize(30);
  fill( 255, 255, 255);
  text("Waiting to communicate with Uno board...", marginx, height/2);
  delay(1500);
  
  // Build com chooser interface
  comSetup(0,0);
  
  // Instatiate grid
  gb1 = new gridBlock(width-marginx, height-marginy, gxpos, gypos, xnodesnr, ynodesnr, xynodespacing);
  
  // Build grid
  gb1.build();
  
  btnsave = new gridNode(100,50,101,0,"Save",false);
  btnsave.nRGB = color(60, 60, 60);
  btnsave.tnRGB = color(255, 255, 255);
  btnsave.onRGB = color(0, 116, 217);
  
  btnrst = new gridNode(100,50,202,0,"Reset",false);
  btnrst.nRGB = color(60, 60, 60);
  btnrst.tnRGB = color(255, 255, 255);
  btnrst.onRGB = color(0, 116, 217);
}

public void draw(){ 
  
  background(204);
  noStroke();
  fill(30,30,30);
  rect(0, 0, width, 50);
  
  // Detect mouse over com interface
  comMouse();
  
  gb1.update();
  btnrst.update();
  btnsave.update();
} 

public void mouseReleased(){
  
  gb1.onclick();
  btnrst.onclick();
  btnsave.onclick();
  
  if (btnrst.nodeFrozen){
    gb1.build();
    btnrst.nodeFrozen = false;
  }
    if (btnsave.nodeFrozen){
      File filename = new File("PhotonLightMap.csv");
      selectOutput("Select a folder to save:", "fileSelected", filename );
      btnsave.nodeFrozen = false;
  }
}

public void fileSelected(File selection) {
  if (selection == null) {
    println("Window was closed or the user hit cancel.");
  } else {
    println("User selected " + selection.getAbsolutePath());
    gb1.export2csv(selection.getAbsolutePath());
  }
}
// Code by DavidBacelj
// https://forum.processing.org/two/discussion/22898/select-com-port-in-sketch-through-drop-down-list-using-controlp5-and-serial-library
// Null value handling added by MakerMatrix




ControlP5 cp5;
DropdownList d1;
 
Serial myPort;

String portName;
int serialListIndex;
int nullCounter = 0;
int readCounter = 0;

public void comSetup(int px, int py){ 

  cp5 = new ControlP5(this);
 
  PFont pfont = createFont("Arial",10,true); //Create a font
  ControlFont font = new ControlFont(pfont,12); //font, font-size
 
  d1 = cp5.addDropdownList("myList-d1")
          .setPosition(px, py)
          .setSize(100, 200)
          .setHeight(210)
          .setItemHeight(40)
          .setBarHeight(50)
          .setFont(font)
          .setColorBackground(color(60))
          .setColorActive(color(255, 128))
          ;
 
      d1.getCaptionLabel().set("PORT"); //set PORT before anything is selected
 
      // Let's check for available ports before we try to instantiate Serial()
      String[] ports = Serial.list();        //Get a list of available ports
      while( ports.length == 0){             //If none are available, stay in this loop
         //println ("No available ports");         
         delay(1000);
         ports = Serial.list();      //Try again every second until a port is available
      }
      
      portName = Serial.list()[0]; //0 as default
      myPort = new Serial(this, portName, baudRate);

}

public void comMouse(){
  
  if(d1.isMouseOver()) {
    d1.clear(); //Delete all the items
    for (int i=0; i<Serial.list().length; i++) {
      d1.addItem(Serial.list()[i], i); //add the items in the list
    }
  }
  
  if ( myPort.available() > 0){                   //read incoming data from serial port
    serialRead = myPort.readStringUntil('\n');
    readCounter++;
    while( serialRead == null){  // Sanity check for null serial values
      nullCounter++;             // Notice and log null, but don't send it
      delay(10);                  // A short delay here minimizes the number of consecutive null reads
      println("Oops, LDR value has been NULL " + nullCounter + " of " + readCounter + " times.");        
      serialRead = myPort.readStringUntil('\n');  // Try again
      readCounter++;
    }
   }
}

public void controlEvent(ControlEvent theEvent) { //when something in the list is selected
    myPort.clear(); //delete the port
    myPort.stop(); //stop the port
    if (theEvent.isController() && d1.isMouseOver()) {
    portName = Serial.list()[PApplet.parseInt(theEvent.getController().getValue())]; //port name is set to the selected port in the dropDownMeny
    myPort = new Serial(this, portName, baudRate); //Create a new connection
    println("Serial index set to: " + theEvent.getController().getValue());
    serialRead = "No Data";
    delay(2000); 
    }
}
// Define a grid made of node instances

class gridBlock {
  
  // Set grid properties, with, height, nr of nodes
  int gxpos, gypos, gw, gh;
  int nxn, nyn;
  int nxpos, nypos, nw, nh, nspc;
  gridNode[][] nodes;

  // Class constructor initiate instance
  gridBlock (int w, int h, int x, int y, int nodexnr, int nodeynr, int nodespacing){
    
    gxpos = x;
    gypos = y;
    gw = w;
    gh = h;
    nxn = nodexnr;
    nyn = nodeynr;
    nspc = nodespacing;
    // nxpos = gxpos;
    // nypos = gypos;
    nw = round(gw / nxn - nspc);
    nh = round(gh / nyn - nspc);
    nodes = new gridNode[nodexnr][nodeynr];
    println(nxpos, nypos, nw, nh);
  
  }
  
  // Calculate node width height
  public void setup() {
    
    //nw = w/nxn;
    //ny = h/nyn;
    
  }
  
  // Create a grid
  public void build() {         
    for (int i=0; i<nxn; i++) {
      for (int j=0; j<nyn; j++) {
        
        nxpos = i*(nw+nspc)+gxpos+nspc/2;
        nypos = j*(nh+nspc)+gypos+nspc/2;
        nodes[i][j] = new gridNode(nw, nh, nxpos, nypos, true );
        // println(nxpos, nypos, nxpos+nw, nypos+nh);
        
      }
    }
 }
 // Redraw grid nodes
 public void update(){
   
   // Label rows and columns
     textSize(nh/3);
     for( int col=0; col<nxn; col++){
       text(nf(col+1), gxpos + 0.5f*nw + col*(nw+nspc), 100);
     }
     for( int row=0; row<nyn; row++){
       text(nf(row+1), 60, gypos + 0.5f*nh + row*(nh+nspc));
     }
     
   // Draw the nodes
     for (int i=0; i<nxn; i++) {
      for (int j=0; j<nyn; j++) {
        nodes[i][j].update();
        nodes[i][j].ntxt = trim(serialRead);
      }
     }
 }
  // Export
 public void export2csv(String path){
   
   Table table = new Table();
   
   for (int i=0; i<nxn; i++) {
     table.addColumn();
   }
   for (int j=0; j<nyn; j++) {
     table.addRow();
   }
     
     for (int i=0; i<nxn; i++) {       
       for (int j=0; j<nyn; j++) {
        table.setString(j, i, nodes[i][j].ntxtFrozen);
        println(nodes[i][j].ntxtFrozen);
        
      }
     }
     
     saveTable(table, path);
 }
 // Calculate mouse actions
 public void onclick(){
     for (int i=0; i<nxn; i++) {
      for (int j=0; j<nyn; j++) {
        nodes[i][j].onclick();
      }
     }
 }
}
// Define the node class

class gridNode {
 
    int nx;
    int ny;
    int nw;
    int nh;
    int nxh;
    int nyh;
    int nwh;
    int nhh;
    boolean xy;
    boolean mouseOver;
    boolean nodeFrozen;
    String ntxt;                             // Normal text to display
    String ntxtFrozen;                       // Frozen text to display
    int nRGB = color(255,255,255);         // Normal color
    int onRGB = color(0,0,0);          // Over Normal color 
    int fRGB = color(25,150,25);           // Frozen color
    int ofRGB = color(225,25,25);              // Over Frozen color
    int tnRGB = color(125,125,125);        // Text Normal color
    int tonRGB = color(255,255,255);       // Text Over Normal color 
    int tfRGB = color(255,255,255);        // Text Frozen color
    int tofRGB = color(0,0,0);       // Text Over Frozen color
    
  gridNode(int w, int h, int x, int y, String txt, boolean coords){
    
    nx = x;
    ny = y;
    nw = w;
    nh = h;
    ntxt = txt;
    xy = coords;
  }
  
  gridNode(int w, int h, int x, int y, boolean coords){
    
    nx = x;
    ny = y;
    nw = w;
    nh = h;
    ntxt = "N/A";
    xy = coords;
    
  }
  
  public void update(){   
    
    if (!nodeFrozen){
    ntxtFrozen = ntxt;
    }
      
    if (mousePressed && ismouseOver()){
      //nx = mouseX - nw/2;
      //ny = mouseY - nh/2;
      //ntxt = "Pressed"
      
      if (nxh == 0) {
        nxh = nx;
        nyh = ny;
        nwh = nw;
        nhh = nh;
      } 

      nx = nxh+2;
      ny = nyh+2;
      nw = nwh-4;
      nh = nhh-4;

    }
    // Draw node state 
    
    // Normal
    if (!ismouseOver() && !nodeFrozen){
      fill(nRGB);
      rect(nx, ny, nw, nh);
      txtdrw(tnRGB);
    }
    // OverFrozen
    else if (ismouseOver() && nodeFrozen){
      fill(ofRGB);
      rect(nx, ny, nw, nh);
      txtdrw(tofRGB);
    }
    // Frozen
    else if (nodeFrozen) {
      fill(fRGB);
      rect(nx, ny, nw, nh);
      txtdrw(tfRGB);
    }
    // OverNormal
    else {
      fill(onRGB);
      rect(nx, ny, nw, nh);
      txtdrw(tonRGB);
    }

    //println(nx, mouseX, mouseOver);
    //println(nodeFrozen, ntxtFrozen);
    //println(nodeFrozen, ntxtFrozen);
    
  }
  
  public void txtdrw(int txtRGB){
    
    // Draw text
    int tsz = nh/4;
    if( xy){
      textAlign(LEFT, TOP);
      fill(txtRGB);
      textSize(tsz/1.5f);
      //String nodeID = "(" + nf(ny/(nh+xynodespacing)) + "," + nf(nx/(nw+xynodespacing)) + ")";
      String nodeID = "(" + nf(ny/nh) + "," + nf(nx/nw) + ")";
      text(nodeID, nx, ny, nw, nh);
    }
      textSize(tsz);
      textAlign(CENTER, CENTER);
    if (!nodeFrozen){
      fill(txtRGB);
      text(ntxt, nx, ny, nw, nh);
    } else {
      fill(txtRGB);
      text(ntxtFrozen, nx, ny, nw, nh);
    }
  }
  
  public void onclick(){
    if (ismouseOver()){
      nodeFrozen = !nodeFrozen;
      nx = nxh;
      ny = nyh;
      nw = nwh;
      nh = nhh;
    }
  }
  
  public boolean ismouseOver() {
    return mouseOver = mouseX >= nx && mouseX <= nx+nw && mouseY >= ny && mouseY <= ny+nh;  
  }

}
  public void settings() {  size(1100, 700); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Light_Meter_Grid_ProcessingSketch" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
